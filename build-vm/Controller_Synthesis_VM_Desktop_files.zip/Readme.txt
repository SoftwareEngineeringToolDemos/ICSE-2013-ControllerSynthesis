******* Steps To Run the tool *******

1. Open a terminal window
2. cd ~/Desktop
3. cd mtsa-3.6/dist
4. java -Xmx1g -Ddebug="false" -Dwarning="true" -Dcontrol-flow="false"  -jar mtsa.jar

******* Steps for Demo *******

1. MTSA Analyser tool should be open on VM startup (or launch from Desktop shortcut or by steps shown above)
2. Select File -> Open and navigate to ~/Desktop/mtsa-3.6/dist/examples/ folder
3. Open one of the examples (.lts extension)
4. Compile using the blue colored "C" button (or Build -> Compile)
5. Navigate to the Draw tab and make a selection on the left pane to view output

Note :- 
Some examples may fail in compile step (use another example instead)
Refer to the youtube demo of the tool (link provided on desktop)
